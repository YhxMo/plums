import type { ErrorObject } from "ajv";
import { FORMAT_UNSUPPORTED, MANIFEST_INVALID, PlumsError } from "../errors.js";
import { secretKeys } from "../secrets.js";
import { validateEnginePermission } from "./engine-permission.js";
import { isTrailingDotTarget, parseEgressTarget } from "./egress-target.js";
import {
  FORMAT_VERSION_PATTERN,
  manifestValidator,
  settingValueFailure,
} from "./schema.js";
import {
  isManifestV1,
  SUPPORTED_FORMAT_MAJOR,
  type Manifest,
} from "./types.js";

/**
 * Parses and checks the text of `manifest.json`.
 * Throws MANIFEST_INVALID or FORMAT_UNSUPPORTED. Never touches the file system.
 */
export function parseManifest(bytes: Uint8Array): Manifest {
  let text: string;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw invalid("manifest.json 不是有效的 UTF-8 文本，无法读取。");
  }
  if (text.charCodeAt(0) === 0xfeff) {
    text = text.slice(1);
  }
  let value: unknown;
  try {
    value = JSON.parse(text);
  } catch {
    throw invalid(
      "manifest.json 不是合法的 JSON，请检查逗号、引号和括号是否写对。",
    );
  }
  return checkManifest(value);
}

/** The only keys an `x-secret` field may have. Why: any other key (default, enum, a nested schema) could carry the secret itself. */
const SECRET_FIELD_KEYS = new Set(["type", "title", "description", "x-secret"]);

export function checkManifest(value: unknown): Manifest {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw invalid("manifest.json 的内容必须是一个 JSON 对象（以 { 开头）。");
  }
  assertFormatSupported((value as Record<string, unknown>).formatVersion);

  const major = Number(
    String((value as Record<string, unknown>).formatVersion).split(".")[0],
  );
  const validate = manifestValidator(major === 2 ? 2 : 1);
  if (validate(value)) {
    const manifest = value as Manifest;
    const bad = manifest.permissions.findIndex(
      (p) =>
        (isManifestV1(manifest) ? p.level === "egress" : p.kind === "egress") &&
        parseEgressTarget(p.target) === undefined,
    );
    if (bad !== -1) {
      const at = `/permissions/${bad}/target`;
      if (isTrailingDotTarget(manifest.permissions[bad]!.target)) {
        throw new PlumsError({
          code: MANIFEST_INVALID,
          message: "主机名不能以点结尾。",
          path: at,
          details: { reason: "TRAILING_DOT" },
        });
      }
      throw invalid(
        "外发权限的 target 只能写主机名（可带端口），如 api.example.com、api.example.com:8443 或 *.example.com；至少两级域名（不能是 com 或 *.com）；不能带 https:// 、路径、IP 或 localhost。",
        at,
      );
    }
    if (!isManifestV1(manifest)) {
      const seen = new Set<string>();
      for (const [index, permission] of manifest.permissions.entries()) {
        if (seen.has(permission.id)) {
          throw new PlumsError({
            code: MANIFEST_INVALID,
            message: "同一包内的权限 id 不能重复。",
            path: `/permissions/${index}/id`,
            details: { reason: "DUPLICATE_PERMISSION_ID" },
          });
        }
        seen.add(permission.id);
        if (permission.kind === "engine")
          validateEnginePermission(permission, `/permissions/${index}`);
      }
    }
    const properties = manifest.settingsSchema?.properties ?? {};
    for (const key of secretKeys(manifest)) {
      const extra = Object.keys(properties[key] ?? {}).find(
        (name) => !SECRET_FIELD_KEYS.has(name),
      );
      if (extra !== undefined) {
        throw invalid(
          `设置项「${key}」是密钥，只能写 type、title、description 和 x-secret，不能写「${extra}」。`,
          `/settingsSchema/properties/${escapePointer(key)}/${escapePointer(extra)}`,
        );
      }
    }
    assertSettingDefaults(manifest);
    return manifest;
  }
  const first = validate.errors?.[0];
  if (first === undefined) {
    throw invalid("manifest.json 的内容不符合包格式。");
  }
  throw toPlumsError(first);
}

function assertSettingDefaults(manifest: Manifest): void {
  const properties = manifest.settingsSchema?.properties ?? {};
  for (const [key, spec] of Object.entries(properties)) {
    // Why skipped: a secret field is already limited to the whitelist, which rejects default and bounds.
    if (spec["x-secret"] === true) continue;
    const at = `/settingsSchema/properties/${escapePointer(key)}`;
    if (
      (spec.minimum !== undefined || spec.maximum !== undefined) &&
      spec.type !== "number" &&
      spec.type !== "integer"
    ) {
      // Why: minimum and maximum are numeric bounds. On text or a boolean they do not mean a range.
      const keyword = spec.minimum !== undefined ? "minimum" : "maximum";
      throw invalid(
        `设置项「${key}」是${typeName(spec.type)}，minimum 和 maximum 只能用在数字上。`,
        `${at}/${keyword}`,
      );
    }
    if (
      spec.default !== undefined &&
      settingValueFailure(spec, spec.default, true) !== undefined
    ) {
      // Why: a default is saved later without asking, so it has to already pass the same rules as a saved value.
      throw invalid(
        `设置项「${key}」的默认值不符合它的类型或范围。`,
        `${at}/default`,
      );
    }
  }
}

function assertFormatSupported(formatVersion: unknown): void {
  if (
    typeof formatVersion !== "string" ||
    !new RegExp(FORMAT_VERSION_PATTERN).test(formatVersion)
  ) {
    return;
  }
  const major = Number(formatVersion.split(".")[0]);
  if (major > SUPPORTED_FORMAT_MAJOR) {
    throw new PlumsError({
      code: FORMAT_UNSUPPORTED,
      message: `这个包使用的格式版本是 ${formatVersion}，当前支持 1.x 至 ${SUPPORTED_FORMAT_MAJOR}.x。请升级 Plums 后再导入。`,
      path: "/formatVersion",
    });
  }
}

function invalid(message: string, path?: string): PlumsError {
  return new PlumsError({
    code: MANIFEST_INVALID,
    message,
    ...(path === undefined ? {} : { path }),
  });
}

function toPlumsError(error: ErrorObject): PlumsError {
  const params = error.params as Record<string, unknown>;
  let path = error.instancePath;
  if (error.keyword === "required") {
    path = `${path}/${escapePointer(String(params.missingProperty))}`;
  }
  const where = describe(path);
  const message = explain(error, path, where, params);
  return invalid(message, path === "" ? undefined : path);
}

function explain(
  error: ErrorObject,
  path: string,
  where: string,
  params: Record<string, unknown>,
): string {
  const field = lastSegment(path);
  switch (error.keyword) {
    case "required":
      return `缺少必填项 ${where}。`;
    case "enum": {
      const allowed = (params.allowedValues as unknown[])
        .map((v) => String(v))
        .join("、");
      return `${where} 的值不对，只能是 ${allowed} 之一。`;
    }
    case "const":
      return `${where} 的值必须是 ${JSON.stringify(params.allowedValue)}。`;
    case "minLength":
      return `${where} 不能为空。`;
    case "maxLength":
      return `${where} 太长了，最多 ${String(params.limit)} 个字符。`;
    case "pattern":
    case "format":
      return `${where} 的写法不对。${hint(field)}`;
    case "type":
      return `${where} 的类型不对，应该是${typeName(String(params.type))}。`;
    default:
      return `${where} 不符合包格式。`;
  }
}

function hint(field: string): string {
  switch (field) {
    case "version":
      return "版本号需要是 主版本.次版本.修订号，例如 1.2.3。";
    case "formatVersion":
      return "格式版本需要写成 主版本.次版本，例如 1.0。";
    case "id":
      return "id 只能用小写字母、数字，以及单个的 . _ - 分隔，例如 my-pack。";
    case "range":
      return "依赖版本需要是版本范围，例如 ^1.2.0 或 >=1.0.0 <2.0.0。";
    default:
      return "";
  }
}

export function typeName(type: string): string {
  switch (type) {
    case "string":
      return "文字";
    case "number":
    case "integer":
      return "数字";
    case "boolean":
      return "是/否（true 或 false）";
    case "array":
      return "列表（用 [ ] 括起来）";
    case "object":
      return "对象（用 { } 括起来）";
    default:
      return type;
  }
}

/** `/permissions/0/level` becomes 「permissions」第 1 项的「level」. */
function describe(path: string): string {
  if (path === "") {
    return "manifest.json";
  }
  const segments = path.split("/").slice(1).map(unescapePointer);
  let out = "";
  segments.forEach((segment, index) => {
    if (/^\d+$/.test(segment)) {
      out += `第 ${Number(segment) + 1} 项`;
    } else {
      out += `${index > 0 ? "的" : ""}「${segment}」`;
    }
  });
  return out;
}

function lastSegment(path: string): string {
  const last = path.slice(path.lastIndexOf("/") + 1);
  return unescapePointer(last);
}

export function escapePointer(segment: string): string {
  return segment.replaceAll("~", "~0").replaceAll("/", "~1");
}

function unescapePointer(segment: string): string {
  return segment.replaceAll("~1", "/").replaceAll("~0", "~");
}
